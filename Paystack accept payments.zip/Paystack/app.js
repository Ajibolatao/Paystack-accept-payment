const   express     = require('express'),
        app         = express(),
        paystack = require('paystack')('sk_test_1b0140f12e42fe87c0be2ce1b07662b69bdb8816');

app.set('view engine', 'ejs')
app.set('views', __dirname + ('/views'))
app.use(express.urlencoded({extended: false}))

//  INDEX ROUTE
app.get('/', (req, res) => {
    res.render('index')
})



// APP LISTEN
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log('server starting')
})